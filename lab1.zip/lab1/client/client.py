import requests

requests.get('http://server:5000')
